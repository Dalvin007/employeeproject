import React from 'react'

export const AddEmployee = () => {
  return (
    <div>AddEmployee</div>
  )
}

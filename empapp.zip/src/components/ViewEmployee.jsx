import React from 'react'

export const ViewEmployee = () => {
  return (
    <div>ViewEmployee</div>
  )
}
